package application;

import java.io.File;
import java.io.FileNotFoundException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;
import javafx.beans.value.ChangeListener;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

public class Controller implements Initializable {
    // FXML variables
    @FXML
    private TextField input;
    @FXML
    private Button addButton;
    @FXML
    private Button removeButton;
    @FXML
    private ListView<String> myList;
    /////////////////////////////////////
    

    public void readFromFile() throws FileNotFoundException {
        // This method reads the file and adds the items to the list
        // Currently not working, thus not used
        Scanner scanner = new Scanner(new File("list.txt"));
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            System.out.println(line);
        }
    }

    String item;
    String[] todoList = { "Finish JavaFX Project", "Study for Chemistry Exam" }; // Default list
    ObservableList<String> observableToDo = FXCollections.observableArrayList(todoList); // Copies the array to an observable list.  The observable list can be dynamically updated.

    String currentSelection; // Used for the remove button

    public void add() {
        System.out.println("Add"); // Debugging
        item = String.valueOf(input.getText()); // Gets the text from the input field
        observableToDo.add(item); // Adds the item to the ListView
        myList.setItems(observableToDo); // Updates the ListView
        input.clear();         // clear the input field

    }

    public void remove() {
        System.out.println("remove");  // Debugging
        observableToDo.remove(currentSelection); // Removes the item from the ListView
        myList.setItems(observableToDo); // Updates the ListView
    }

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {

        /*
         * try {
         * readFromFile();
         * } catch (FileNotFoundException e) {
         * 
         * e.printStackTrace();
         * }
         */

        myList.getItems().addAll(todoList);  // Adds the default list to the ListView
        myList.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() { 
            @Override
            public void changed(javafx.beans.value.ObservableValue<? extends String> observable, String oldValue,
                    String newValue) { // This method is called whenever the user selects an item from the ListView
                System.out.println("Selected item: " + newValue);
                currentSelection = newValue;  // Sets the current selection to the item that was clicked
            }
        });
    }
}
